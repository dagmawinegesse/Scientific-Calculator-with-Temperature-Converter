﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backspaceButton = new System.Windows.Forms.Button();
            this.cancelallButton = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.txtdisplay = new System.Windows.Forms.TextBox();
            this.lblshowOperation = new System.Windows.Forms.Label();
            this.findpercentage = new System.Windows.Forms.Button();
            this.ToOct = new System.Windows.Forms.Button();
            this.naturalLog = new System.Windows.Forms.Button();
            this.ToHex = new System.Windows.Forms.Button();
            this.Tan = new System.Windows.Forms.Button();
            this.Tanh = new System.Windows.Forms.Button();
            this.inverse = new System.Windows.Forms.Button();
            this.toBinary = new System.Windows.Forms.Button();
            this.Cos = new System.Windows.Forms.Button();
            this.Cosh = new System.Windows.Forms.Button();
            this.poweredby3 = new System.Windows.Forms.Button();
            this.ToDec = new System.Windows.Forms.Button();
            this.Sin = new System.Windows.Forms.Button();
            this.sinh = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.equals = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.powerby2 = new System.Windows.Forms.Button();
            this.SquareRoot = new System.Windows.Forms.Button();
            this.LOG = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.calculatorTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.standardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sientificToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.temperatureConverterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MOD = new System.Windows.Forms.Button();
            this.EXP = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.celToFahrenite = new System.Windows.Forms.RadioButton();
            this.FahToCel = new System.Windows.Forms.RadioButton();
            this.ToKevin = new System.Windows.Forms.RadioButton();
            this.txtEnterValue = new System.Windows.Forms.TextBox();
            this.convertAction = new System.Windows.Forms.Button();
            this.txtConverted = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // backspaceButton
            // 
            this.backspaceButton.BackColor = System.Drawing.Color.Black;
            this.backspaceButton.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backspaceButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.backspaceButton.Location = new System.Drawing.Point(12, 142);
            this.backspaceButton.Name = "backspaceButton";
            this.backspaceButton.Size = new System.Drawing.Size(117, 84);
            this.backspaceButton.TabIndex = 0;
            this.backspaceButton.Text = "⌫";
            this.backspaceButton.UseVisualStyleBackColor = false;
            this.backspaceButton.Click += new System.EventHandler(this.backspaceButton_Click);
            // 
            // cancelallButton
            // 
            this.cancelallButton.BackColor = System.Drawing.Color.Black;
            this.cancelallButton.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelallButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.cancelallButton.Location = new System.Drawing.Point(135, 142);
            this.cancelallButton.Name = "cancelallButton";
            this.cancelallButton.Size = new System.Drawing.Size(117, 84);
            this.cancelallButton.TabIndex = 1;
            this.cancelallButton.Text = "CE";
            this.cancelallButton.UseVisualStyleBackColor = false;
            this.cancelallButton.Click += new System.EventHandler(this.cancelallButton_Click);
            // 
            // Cancel
            // 
            this.Cancel.BackColor = System.Drawing.Color.Black;
            this.Cancel.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cancel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Cancel.Location = new System.Drawing.Point(258, 142);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(117, 84);
            this.Cancel.TabIndex = 2;
            this.Cancel.Text = "C";
            this.Cancel.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Black;
            this.button4.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button4.Location = new System.Drawing.Point(381, 142);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(117, 87);
            this.button4.TabIndex = 3;
            this.button4.Text = "±";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Black;
            this.button5.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button5.Location = new System.Drawing.Point(381, 232);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(117, 84);
            this.button5.TabIndex = 7;
            this.button5.Text = "+";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.arithmeticOperation);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Black;
            this.button6.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button6.Location = new System.Drawing.Point(258, 232);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(117, 84);
            this.button6.TabIndex = 6;
            this.button6.Text = "9";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.numbutton_click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Black;
            this.button7.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button7.Location = new System.Drawing.Point(135, 232);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(117, 84);
            this.button7.TabIndex = 5;
            this.button7.Text = "8";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.numbutton_click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Black;
            this.button8.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button8.Location = new System.Drawing.Point(12, 232);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(117, 84);
            this.button8.TabIndex = 4;
            this.button8.Text = "7";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.numbutton_click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Black;
            this.button9.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button9.Location = new System.Drawing.Point(381, 322);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(117, 84);
            this.button9.TabIndex = 11;
            this.button9.Text = "-";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.arithmeticOperation);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Black;
            this.button10.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button10.Location = new System.Drawing.Point(258, 322);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(117, 84);
            this.button10.TabIndex = 10;
            this.button10.Text = "6";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.numbutton_click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Black;
            this.button11.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button11.Location = new System.Drawing.Point(135, 322);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(117, 84);
            this.button11.TabIndex = 9;
            this.button11.Text = "5";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.numbutton_click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Black;
            this.button12.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button12.Location = new System.Drawing.Point(12, 322);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(117, 84);
            this.button12.TabIndex = 8;
            this.button12.Text = "4";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.numbutton_click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Black;
            this.button13.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button13.Location = new System.Drawing.Point(381, 415);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(117, 84);
            this.button13.TabIndex = 15;
            this.button13.Text = "*";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.arithmeticOperation);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Black;
            this.button14.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button14.Location = new System.Drawing.Point(258, 412);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(117, 84);
            this.button14.TabIndex = 14;
            this.button14.Text = "3";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.numbutton_click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Black;
            this.button15.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button15.Location = new System.Drawing.Point(135, 412);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(117, 84);
            this.button15.TabIndex = 13;
            this.button15.Text = "2";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.numbutton_click);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Black;
            this.button16.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button16.Location = new System.Drawing.Point(12, 412);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(117, 84);
            this.button16.TabIndex = 12;
            this.button16.Text = "1";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.numbutton_click);
            // 
            // txtdisplay
            // 
            this.txtdisplay.BackColor = System.Drawing.Color.Tan;
            this.txtdisplay.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdisplay.Location = new System.Drawing.Point(12, 52);
            this.txtdisplay.Multiline = true;
            this.txtdisplay.Name = "txtdisplay";
            this.txtdisplay.Size = new System.Drawing.Size(486, 83);
            this.txtdisplay.TabIndex = 16;
            this.txtdisplay.Text = "0";
            this.txtdisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblshowOperation
            // 
            this.lblshowOperation.AutoSize = true;
            this.lblshowOperation.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblshowOperation.Location = new System.Drawing.Point(24, 58);
            this.lblshowOperation.Name = "lblshowOperation";
            this.lblshowOperation.Size = new System.Drawing.Size(0, 26);
            this.lblshowOperation.TabIndex = 17;
            this.lblshowOperation.Click += new System.EventHandler(this.label1_Click);
            // 
            // findpercentage
            // 
            this.findpercentage.BackColor = System.Drawing.Color.Black;
            this.findpercentage.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.findpercentage.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.findpercentage.Location = new System.Drawing.Point(993, 509);
            this.findpercentage.Name = "findpercentage";
            this.findpercentage.Size = new System.Drawing.Size(117, 84);
            this.findpercentage.TabIndex = 33;
            this.findpercentage.Text = "%";
            this.findpercentage.UseVisualStyleBackColor = false;
            this.findpercentage.Click += new System.EventHandler(this.findpercentage_Click);
            // 
            // ToOct
            // 
            this.ToOct.BackColor = System.Drawing.Color.Black;
            this.ToOct.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToOct.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ToOct.Location = new System.Drawing.Point(856, 415);
            this.ToOct.Name = "ToOct";
            this.ToOct.Size = new System.Drawing.Size(117, 84);
            this.ToOct.TabIndex = 32;
            this.ToOct.Text = "OCT";
            this.ToOct.UseVisualStyleBackColor = false;
            this.ToOct.Click += new System.EventHandler(this.ToOct_Click);
            // 
            // naturalLog
            // 
            this.naturalLog.BackColor = System.Drawing.Color.Black;
            this.naturalLog.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.naturalLog.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.naturalLog.Location = new System.Drawing.Point(993, 412);
            this.naturalLog.Name = "naturalLog";
            this.naturalLog.Size = new System.Drawing.Size(117, 84);
            this.naturalLog.TabIndex = 29;
            this.naturalLog.Text = "lnX";
            this.naturalLog.UseVisualStyleBackColor = false;
            this.naturalLog.Click += new System.EventHandler(this.naturalLog_Click);
            // 
            // ToHex
            // 
            this.ToHex.BackColor = System.Drawing.Color.Black;
            this.ToHex.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToHex.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ToHex.Location = new System.Drawing.Point(856, 505);
            this.ToHex.Name = "ToHex";
            this.ToHex.Size = new System.Drawing.Size(117, 84);
            this.ToHex.TabIndex = 28;
            this.ToHex.Text = "HEX";
            this.ToHex.UseVisualStyleBackColor = false;
            this.ToHex.Click += new System.EventHandler(this.ToHex_Click);
            // 
            // Tan
            // 
            this.Tan.BackColor = System.Drawing.Color.Black;
            this.Tan.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tan.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Tan.Location = new System.Drawing.Point(721, 412);
            this.Tan.Name = "Tan";
            this.Tan.Size = new System.Drawing.Size(117, 84);
            this.Tan.TabIndex = 27;
            this.Tan.Text = "Tan";
            this.Tan.UseVisualStyleBackColor = false;
            this.Tan.Click += new System.EventHandler(this.Tan_Click);
            // 
            // Tanh
            // 
            this.Tanh.BackColor = System.Drawing.Color.Black;
            this.Tanh.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tanh.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Tanh.Location = new System.Drawing.Point(589, 412);
            this.Tanh.Name = "Tanh";
            this.Tanh.Size = new System.Drawing.Size(117, 84);
            this.Tanh.TabIndex = 26;
            this.Tanh.Text = "Tanh";
            this.Tanh.UseVisualStyleBackColor = false;
            this.Tanh.Click += new System.EventHandler(this.Tanh_Click);
            // 
            // inverse
            // 
            this.inverse.BackColor = System.Drawing.Color.Black;
            this.inverse.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inverse.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.inverse.Location = new System.Drawing.Point(993, 322);
            this.inverse.Name = "inverse";
            this.inverse.Size = new System.Drawing.Size(117, 84);
            this.inverse.TabIndex = 25;
            this.inverse.Text = "1/x";
            this.inverse.UseVisualStyleBackColor = false;
            this.inverse.Click += new System.EventHandler(this.inverse_Click);
            // 
            // toBinary
            // 
            this.toBinary.BackColor = System.Drawing.Color.Black;
            this.toBinary.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toBinary.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.toBinary.Location = new System.Drawing.Point(856, 322);
            this.toBinary.Name = "toBinary";
            this.toBinary.Size = new System.Drawing.Size(117, 84);
            this.toBinary.TabIndex = 24;
            this.toBinary.Text = "BIN";
            this.toBinary.UseVisualStyleBackColor = false;
            this.toBinary.Click += new System.EventHandler(this.toBinary_Click);
            // 
            // Cos
            // 
            this.Cos.BackColor = System.Drawing.Color.Black;
            this.Cos.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cos.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Cos.Location = new System.Drawing.Point(721, 322);
            this.Cos.Name = "Cos";
            this.Cos.Size = new System.Drawing.Size(117, 84);
            this.Cos.TabIndex = 23;
            this.Cos.Text = "Cos";
            this.Cos.UseVisualStyleBackColor = false;
            this.Cos.Click += new System.EventHandler(this.Cos_Click);
            // 
            // Cosh
            // 
            this.Cosh.BackColor = System.Drawing.Color.Black;
            this.Cosh.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cosh.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Cosh.Location = new System.Drawing.Point(589, 322);
            this.Cosh.Name = "Cosh";
            this.Cosh.Size = new System.Drawing.Size(117, 84);
            this.Cosh.TabIndex = 22;
            this.Cosh.Text = "Cosh";
            this.Cosh.UseVisualStyleBackColor = false;
            this.Cosh.Click += new System.EventHandler(this.Cosh_Click);
            // 
            // poweredby3
            // 
            this.poweredby3.BackColor = System.Drawing.Color.Black;
            this.poweredby3.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.poweredby3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.poweredby3.Location = new System.Drawing.Point(993, 232);
            this.poweredby3.Name = "poweredby3";
            this.poweredby3.Size = new System.Drawing.Size(117, 84);
            this.poweredby3.TabIndex = 21;
            this.poweredby3.Text = "x^3";
            this.poweredby3.UseVisualStyleBackColor = false;
            this.poweredby3.Click += new System.EventHandler(this.poweredby3_Click);
            // 
            // ToDec
            // 
            this.ToDec.BackColor = System.Drawing.Color.Black;
            this.ToDec.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToDec.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ToDec.Location = new System.Drawing.Point(856, 232);
            this.ToDec.Name = "ToDec";
            this.ToDec.Size = new System.Drawing.Size(117, 84);
            this.ToDec.TabIndex = 20;
            this.ToDec.Text = "DEC";
            this.ToDec.UseVisualStyleBackColor = false;
            this.ToDec.Click += new System.EventHandler(this.ToDec_Click);
            // 
            // Sin
            // 
            this.Sin.BackColor = System.Drawing.Color.Black;
            this.Sin.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sin.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Sin.Location = new System.Drawing.Point(721, 232);
            this.Sin.Name = "Sin";
            this.Sin.Size = new System.Drawing.Size(117, 84);
            this.Sin.TabIndex = 19;
            this.Sin.Text = "Sin";
            this.Sin.UseVisualStyleBackColor = false;
            this.Sin.Click += new System.EventHandler(this.Sin_Click);
            // 
            // sinh
            // 
            this.sinh.BackColor = System.Drawing.Color.Black;
            this.sinh.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sinh.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.sinh.Location = new System.Drawing.Point(589, 234);
            this.sinh.Name = "sinh";
            this.sinh.Size = new System.Drawing.Size(117, 84);
            this.sinh.TabIndex = 18;
            this.sinh.Text = "Sinh";
            this.sinh.UseVisualStyleBackColor = false;
            this.sinh.Click += new System.EventHandler(this.button32_Click);
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.Black;
            this.button33.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button33.Location = new System.Drawing.Point(381, 505);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(117, 84);
            this.button33.TabIndex = 37;
            this.button33.Text = "/";
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Click += new System.EventHandler(this.arithmeticOperation);
            // 
            // equals
            // 
            this.equals.BackColor = System.Drawing.Color.Black;
            this.equals.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.equals.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.equals.Location = new System.Drawing.Point(258, 505);
            this.equals.Name = "equals";
            this.equals.Size = new System.Drawing.Size(117, 84);
            this.equals.TabIndex = 36;
            this.equals.Text = "=";
            this.equals.UseVisualStyleBackColor = false;
            this.equals.Click += new System.EventHandler(this.equals_Click);
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.Black;
            this.button35.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button35.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button35.Location = new System.Drawing.Point(135, 505);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(117, 84);
            this.button35.TabIndex = 35;
            this.button35.Text = ".";
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Click += new System.EventHandler(this.numbutton_click);
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.Black;
            this.button36.Font = new System.Drawing.Font("Yu Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button36.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button36.Location = new System.Drawing.Point(12, 505);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(117, 84);
            this.button36.TabIndex = 34;
            this.button36.Text = "0";
            this.button36.UseVisualStyleBackColor = false;
            this.button36.Click += new System.EventHandler(this.numbutton_click);
            // 
            // powerby2
            // 
            this.powerby2.BackColor = System.Drawing.Color.Black;
            this.powerby2.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.powerby2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.powerby2.Location = new System.Drawing.Point(993, 142);
            this.powerby2.Name = "powerby2";
            this.powerby2.Size = new System.Drawing.Size(117, 84);
            this.powerby2.TabIndex = 41;
            this.powerby2.Text = "x^2";
            this.powerby2.UseVisualStyleBackColor = false;
            this.powerby2.Click += new System.EventHandler(this.powerby2_Click);
            // 
            // SquareRoot
            // 
            this.SquareRoot.BackColor = System.Drawing.Color.Black;
            this.SquareRoot.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SquareRoot.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.SquareRoot.Location = new System.Drawing.Point(856, 142);
            this.SquareRoot.Name = "SquareRoot";
            this.SquareRoot.Size = new System.Drawing.Size(117, 84);
            this.SquareRoot.TabIndex = 40;
            this.SquareRoot.Text = "√";
            this.SquareRoot.UseVisualStyleBackColor = false;
            this.SquareRoot.Click += new System.EventHandler(this.SquareRoot_Click);
            // 
            // LOG
            // 
            this.LOG.BackColor = System.Drawing.Color.Black;
            this.LOG.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LOG.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.LOG.Location = new System.Drawing.Point(721, 142);
            this.LOG.Name = "LOG";
            this.LOG.Size = new System.Drawing.Size(117, 84);
            this.LOG.TabIndex = 39;
            this.LOG.Text = "LOG";
            this.LOG.UseVisualStyleBackColor = false;
            this.LOG.Click += new System.EventHandler(this.LOG_Click);
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.Black;
            this.button40.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button40.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button40.Location = new System.Drawing.Point(589, 142);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(117, 84);
            this.button40.TabIndex = 38;
            this.button40.Text = "π";
            this.button40.UseVisualStyleBackColor = false;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calculatorTypeToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1593, 33);
            this.menuStrip1.TabIndex = 42;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // calculatorTypeToolStripMenuItem
            // 
            this.calculatorTypeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.standardToolStripMenuItem,
            this.sientificToolStripMenuItem,
            this.temperatureConverterToolStripMenuItem});
            this.calculatorTypeToolStripMenuItem.Name = "calculatorTypeToolStripMenuItem";
            this.calculatorTypeToolStripMenuItem.Size = new System.Drawing.Size(144, 29);
            this.calculatorTypeToolStripMenuItem.Text = "Calculator Type";
            // 
            // standardToolStripMenuItem
            // 
            this.standardToolStripMenuItem.Name = "standardToolStripMenuItem";
            this.standardToolStripMenuItem.Size = new System.Drawing.Size(276, 30);
            this.standardToolStripMenuItem.Text = "Standard";
            this.standardToolStripMenuItem.Click += new System.EventHandler(this.standardToolStripMenuItem_Click);
            // 
            // sientificToolStripMenuItem
            // 
            this.sientificToolStripMenuItem.Name = "sientificToolStripMenuItem";
            this.sientificToolStripMenuItem.Size = new System.Drawing.Size(276, 30);
            this.sientificToolStripMenuItem.Text = "Sientific";
            this.sientificToolStripMenuItem.Click += new System.EventHandler(this.sientificToolStripMenuItem_Click);
            // 
            // temperatureConverterToolStripMenuItem
            // 
            this.temperatureConverterToolStripMenuItem.Name = "temperatureConverterToolStripMenuItem";
            this.temperatureConverterToolStripMenuItem.Size = new System.Drawing.Size(276, 30);
            this.temperatureConverterToolStripMenuItem.Text = "Temperature Converter";
            this.temperatureConverterToolStripMenuItem.Click += new System.EventHandler(this.temperatureConverterToolStripMenuItem_Click);
            // 
            // MOD
            // 
            this.MOD.BackColor = System.Drawing.Color.Black;
            this.MOD.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MOD.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.MOD.Location = new System.Drawing.Point(721, 509);
            this.MOD.Name = "MOD";
            this.MOD.Size = new System.Drawing.Size(117, 84);
            this.MOD.TabIndex = 43;
            this.MOD.Text = "MOD";
            this.MOD.UseVisualStyleBackColor = false;
            this.MOD.Click += new System.EventHandler(this.arithmeticOperation);
            // 
            // EXP
            // 
            this.EXP.BackColor = System.Drawing.Color.Black;
            this.EXP.Font = new System.Drawing.Font("Yu Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EXP.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.EXP.Location = new System.Drawing.Point(589, 509);
            this.EXP.Name = "EXP";
            this.EXP.Size = new System.Drawing.Size(117, 84);
            this.EXP.TabIndex = 44;
            this.EXP.Text = "EXP";
            this.EXP.UseVisualStyleBackColor = false;
            this.EXP.Click += new System.EventHandler(this.arithmeticOperation);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1116, 148);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(452, 46);
            this.label1.TabIndex = 45;
            this.label1.Text = "Temperature Converter";
            // 
            // celToFahrenite
            // 
            this.celToFahrenite.AutoSize = true;
            this.celToFahrenite.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.celToFahrenite.Location = new System.Drawing.Point(17, 15);
            this.celToFahrenite.Name = "celToFahrenite";
            this.celToFahrenite.Size = new System.Drawing.Size(379, 33);
            this.celToFahrenite.TabIndex = 46;
            this.celToFahrenite.TabStop = true;
            this.celToFahrenite.Text = "Conver Celcius To Fahrentite";
            this.celToFahrenite.UseVisualStyleBackColor = true;
            this.celToFahrenite.CheckedChanged += new System.EventHandler(this.celToFahrenite_CheckedChanged);
            // 
            // FahToCel
            // 
            this.FahToCel.AutoSize = true;
            this.FahToCel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FahToCel.Location = new System.Drawing.Point(17, 63);
            this.FahToCel.Name = "FahToCel";
            this.FahToCel.Size = new System.Drawing.Size(386, 33);
            this.FahToCel.TabIndex = 47;
            this.FahToCel.TabStop = true;
            this.FahToCel.Text = "Convert  Fahrenite To Celcius";
            this.FahToCel.UseVisualStyleBackColor = true;
            this.FahToCel.CheckedChanged += new System.EventHandler(this.FahToCel_CheckedChanged);
            // 
            // ToKevin
            // 
            this.ToKevin.AutoSize = true;
            this.ToKevin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToKevin.Location = new System.Drawing.Point(17, 114);
            this.ToKevin.Name = "ToKevin";
            this.ToKevin.Size = new System.Drawing.Size(229, 33);
            this.ToKevin.TabIndex = 48;
            this.ToKevin.TabStop = true;
            this.ToKevin.Text = "Convert to Kevin";
            this.ToKevin.UseVisualStyleBackColor = true;
            this.ToKevin.CheckedChanged += new System.EventHandler(this.ToKevin_CheckedChanged);
            // 
            // txtEnterValue
            // 
            this.txtEnterValue.Location = new System.Drawing.Point(1349, 196);
            this.txtEnterValue.Multiline = true;
            this.txtEnterValue.Name = "txtEnterValue";
            this.txtEnterValue.Size = new System.Drawing.Size(169, 46);
            this.txtEnterValue.TabIndex = 49;
            this.txtEnterValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // convertAction
            // 
            this.convertAction.Location = new System.Drawing.Point(1197, 505);
            this.convertAction.Name = "convertAction";
            this.convertAction.Size = new System.Drawing.Size(118, 66);
            this.convertAction.TabIndex = 50;
            this.convertAction.Text = "Convert";
            this.convertAction.UseVisualStyleBackColor = true;
            this.convertAction.Click += new System.EventHandler(this.convertAction_Click);
            // 
            // txtConverted
            // 
            this.txtConverted.Location = new System.Drawing.Point(1362, 429);
            this.txtConverted.Multiline = true;
            this.txtConverted.Name = "txtConverted";
            this.txtConverted.Size = new System.Drawing.Size(219, 50);
            this.txtConverted.TabIndex = 51;
            this.txtConverted.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1162, 444);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 25);
            this.label2.TabIndex = 52;
            this.label2.Text = "Converted Temp:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1183, 204);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 25);
            this.label3.TabIndex = 53;
            this.label3.Text = "Enter Value:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.groupBox1.Controls.Add(this.celToFahrenite);
            this.groupBox1.Controls.Add(this.FahToCel);
            this.groupBox1.Controls.Add(this.ToKevin);
            this.groupBox1.Location = new System.Drawing.Point(1142, 259);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(415, 164);
            this.groupBox1.TabIndex = 54;
            this.groupBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(1593, 614);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtConverted);
            this.Controls.Add(this.convertAction);
            this.Controls.Add(this.txtEnterValue);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.EXP);
            this.Controls.Add(this.MOD);
            this.Controls.Add(this.powerby2);
            this.Controls.Add(this.SquareRoot);
            this.Controls.Add(this.LOG);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.equals);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.findpercentage);
            this.Controls.Add(this.ToOct);
            this.Controls.Add(this.naturalLog);
            this.Controls.Add(this.ToHex);
            this.Controls.Add(this.Tan);
            this.Controls.Add(this.Tanh);
            this.Controls.Add(this.inverse);
            this.Controls.Add(this.toBinary);
            this.Controls.Add(this.Cos);
            this.Controls.Add(this.Cosh);
            this.Controls.Add(this.poweredby3);
            this.Controls.Add(this.ToDec);
            this.Controls.Add(this.Sin);
            this.Controls.Add(this.sinh);
            this.Controls.Add(this.lblshowOperation);
            this.Controls.Add(this.txtdisplay);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.cancelallButton);
            this.Controls.Add(this.backspaceButton);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button backspaceButton;
        private System.Windows.Forms.Button cancelallButton;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.TextBox txtdisplay;
        private System.Windows.Forms.Label lblshowOperation;
        private System.Windows.Forms.Button findpercentage;
        private System.Windows.Forms.Button ToOct;
        private System.Windows.Forms.Button naturalLog;
        private System.Windows.Forms.Button ToHex;
        private System.Windows.Forms.Button Tan;
        private System.Windows.Forms.Button Tanh;
        private System.Windows.Forms.Button inverse;
        private System.Windows.Forms.Button toBinary;
        private System.Windows.Forms.Button Cos;
        private System.Windows.Forms.Button Cosh;
        private System.Windows.Forms.Button poweredby3;
        private System.Windows.Forms.Button ToDec;
        private System.Windows.Forms.Button Sin;
        private System.Windows.Forms.Button sinh;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button equals;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button powerby2;
        private System.Windows.Forms.Button SquareRoot;
        private System.Windows.Forms.Button LOG;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem calculatorTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem standardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sientificToolStripMenuItem;
        private System.Windows.Forms.Button MOD;
        private System.Windows.Forms.Button EXP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton celToFahrenite;
        private System.Windows.Forms.RadioButton FahToCel;
        private System.Windows.Forms.RadioButton ToKevin;
        private System.Windows.Forms.TextBox txtEnterValue;
        private System.Windows.Forms.Button convertAction;
        private System.Windows.Forms.TextBox txtConverted;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem temperatureConverterToolStripMenuItem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

